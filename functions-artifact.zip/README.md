Infrastructure: Terraform

This folder contains Terraform configuration to provision GCP resources needed by the Timer App:

- Service account for CI/deployer
- Storage bucket for function artifacts
- Pub/Sub topic, Cloud Function, and Cloud Scheduler job
- IAM bindings necessary for deployment

Usage (CI)

The GitHub Actions workflow `./.github/workflows/deploy.yml` builds the app, packages the `functions/` folder into `functions-artifact.zip`, authenticates to GCP using `GCP_SA_KEY` secret, and runs Terraform `apply` pointing at that artifact.

Local testing

1. Install Terraform and gcloud.
2. Create a terraform.tfvars based on `terraform.tfvars.example` and set values.
3. Ensure `functions-artifact.zip` exists at the path specified in `function_zip_path` (CI will create it for you). For local run you can create the zip manually:

   cd functions
   zip -r ../functions-artifact.zip .

4. Run:

   terraform init
   terraform apply -var-file=terraform.tfvars

Secrets required by CI (GitHub repository secrets)

- GCP_SA_KEY: service account JSON content (used for auth in CI)
- GCP_PROJECT: GCP project id
- FIREBASE_TOKEN: (optional) if you prefer firebase-tools CI auth via token for hosting deploy

Notes

- This is a starting scaffold. Review IAM roles and restrict them to least privilege before using in production.
- Consider configuring a remote Terraform backend (GCS bucket or Terraform Cloud) to store state safely.
